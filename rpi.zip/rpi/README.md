# Raspberry Pi RTSPS → cloud HLS pusher

The RPi runs four `ffmpeg` processes (one per printer), each pulling RTSPS from a Bambu printer on the LAN and pushing HLS segments **out** as HTTP `PUT`s to the cloud relay (`https://printers.tkalve.dev/ingest/<name>/...`). The shop firewall only allows outbound 443, which is why we don't use RTMP/1935.

`-c copy` means there is **no transcoding** — the H.264 stream from the printer is just remuxed into MPEG-TS HLS segments. CPU/RAM usage on a Pi 4 is negligible.

## Files

```
deploy/rpi/
├── bambu-stream@.service        # systemd template, one instance per stream
├── common.env.example           # shared env (RELAY_HOST, PUBLISH_TOKEN)
├── printers.env.example         # per-printer values, for reference
└── install.sh                   # installs ffmpeg, the unit, and the env files
```

## Prereqs

- Raspberry Pi OS Trixie (or Bookworm with backports), ffmpeg ≥ 7.0 from apt is fine.
- Each printer has **LAN Mode → LAN Only LiveView** turned on.
- Cloud relay already deployed (see `deploy/azure/`) and `printers.tkalve.dev` resolving.

## Install

Copy the `deploy/rpi/` directory to the Pi (e.g. `scp -r deploy/rpi pi@rpi:~/bambu-stream`), then:

```bash
cd ~/bambu-stream
sudo ./install.sh

# Set the shared publish token (must match terraform.tfvars on the cloud side).
sudo nano /etc/bambu-stream/common.env

sudo systemctl start \
    bambu-stream@mono.service \
    bambu-stream@slushmaskinen.service \
    bambu-stream@mrfreeze.service \
    bambu-stream@quattroformaggi.service

journalctl -fu 'bambu-stream@*'
```

## Verifying

From your laptop:

```bash
ffprobe -v error -hide_banner https://printers.tkalve.dev/mono/index.m3u8
```

Or just open `deploy/viewer/viewer.html` in a browser.

## Tweaking which printers run on this Pi

- Enable/disable individual streams: `sudo systemctl disable --now bambu-stream@mrfreeze.service`
- Change a printer's IP/code: edit `/etc/bambu-stream/<name>.env`, then `sudo systemctl restart bambu-stream@<name>.service`
- Add a new printer: drop a new `<name>.env` file in `/etc/bambu-stream/`, add the name to `local.streams` in `deploy/azure/terraform/main.tf`, `terraform apply`, then `systemctl enable --now bambu-stream@<name>.service`.
