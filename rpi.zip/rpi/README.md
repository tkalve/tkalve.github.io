# Raspberry Pi RTSPS → cloud HLS pusher

The RPi runs four `ffmpeg` processes (one per printer), each pulling RTSPS from a Bambu printer on the LAN and pushing HLS segments **out** as HTTP `PUT`s to the cloud relay (`https://printers.tkalve.dev/ingest/<name>/...`). The shop firewall only allows outbound 443, which is why we don't use RTMP/1935.

`-c copy` means there is **no transcoding** — the H.264 stream from the printer is just remuxed into MPEG-TS HLS segments. CPU/RAM usage on a Pi 4 is negligible.

## Files

```
deploy/rpi/
├── stream/
│   ├── bambu-stream@.service        # systemd template, one instance per stream
│   ├── bambu-stream.sh              # ffmpeg → cloud relay loop script
│   ├── common.env.example           # shared env (RELAY_HOST, PUBLISH_TOKEN)
│   ├── printers.env.example         # per-printer values, for reference
│   ├── report-ip.sh/service/yaml    # boot-time IP reporter
│   └── install.sh                   # installs ffmpeg, the unit, and any *.env files
└── screenshots/
    ├── bambu-screenshots@.service   # systemd template, one instance per printer
    ├── bambu-screenshot.sh          # ffmpeg frame-grab → backend loop script
    ├── common.env.example           # shared env (SCREENSHOT_ENDPOINT, SCREENSHOT_INTERVAL)
    ├── printers.env.example         # per-printer values, for reference
    └── install.sh                   # installs ffmpeg, the unit, and any *.env files
```

## Prereqs

- Raspberry Pi OS Trixie (or Bookworm with backports), ffmpeg ≥ 7.0 from apt is fine.
- Each printer has **LAN Mode → LAN Only LiveView** turned on.
- Cloud relay already deployed (see `deploy/azure/`) and `printers.tkalve.dev` resolving.

## Install

Copy the relevant subdirectory to the Pi, along with your `.env` files, then run `install.sh`.
The script copies all `*.env` files from its own directory to `/etc/bambu-stream/` automatically.

### Streaming

```bash
# Place your env files alongside install.sh before copying, e.g.:
#   stream/common.env        (from common.env.example)
#   stream/mono.env          (per-printer)
scp -r deploy/rpi/stream pi@rpi:~/bambu-stream
ssh pi@rpi "cd ~/bambu-stream && sudo ./install.sh"

sudo systemctl start 'bambu-stream@*.service'
journalctl -fu 'bambu-stream@*'
```

### Screenshots

```bash
scp -r deploy/rpi/screenshots pi@rpi:~/bambu-screenshots
ssh pi@rpi "cd ~/bambu-screenshots && sudo ./install.sh"

sudo systemctl start 'bambu-screenshots@*.service'
journalctl -fu 'bambu-screenshots@*'
```

## Verifying

From your laptop:

```bash
ffprobe -v error -hide_banner https://printers.tkalve.dev/mono/index.m3u8
```

Or just open `deploy/viewer/viewer.html` in a browser.

## Tweaking which printers run on this Pi

- Enable/disable individual streams: `sudo systemctl disable --now bambu-stream@mrfreeze.service`
- Change a printer's IP/code: edit `/etc/bambu-stream/<name>.env`, then `sudo systemctl restart bambu-stream@<name>.service`
- Add a new printer: drop a new `<name>.env` file in `/etc/bambu-stream/`, add the name to `local.streams` in `deploy/azure/terraform/main.tf`, `terraform apply`, then `systemctl enable --now bambu-stream@<name>.service`.
