#!/usr/bin/env bash
# Install ffmpeg + the bambu-stream@ systemd template + 4 instance env files.
# Run as root (or with sudo) on the Raspberry Pi.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run as root: sudo $0" >&2
    exit 1
fi

SRC_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

echo ">>> Installing dependencies"
apt-get update -y
apt-get install -y --no-install-recommends ffmpeg ca-certificates curl

echo ">>> Creating /etc/bambu-stream"
install -d -m 0755 /etc/bambu-stream

# common.env: pulled from this directory if present, otherwise from .example.
if [[ -f "$SRC_DIR/common.env" ]]; then
    install -m 0640 "$SRC_DIR/common.env" /etc/bambu-stream/common.env
elif [[ ! -f /etc/bambu-stream/common.env ]]; then
    install -m 0640 "$SRC_DIR/common.env.example" /etc/bambu-stream/common.env
    echo "!!! /etc/bambu-stream/common.env created from example."
    echo "!!! EDIT IT and set PUBLISH_TOKEN before starting the services."
fi

# Per-printer env files. Defaults come from printers.env.example which holds
# every printer in one file; we split it into one file per stream.
echo ">>> Writing per-printer env files (will not overwrite existing)"
write_printer_env() {
    local name="$1" id="$2" host="$3" code="$4"
    local target="/etc/bambu-stream/${name}.env"
    if [[ -e "$target" ]]; then
        echo "    keep   $target (exists)"
        return
    fi
    cat >"$target" <<EOF
PRINTER_ID=${id}
PRINTER_HOST=${host}
PRINTER_CODE=${code}
STREAM_NAME=${name}
EOF
    chmod 0640 "$target"
    echo "    write  $target"
}

write_printer_env mono            12 10.95.0.10 8df9c1e0
write_printer_env slushmaskinen   10 10.95.0.9  70d70ee2
write_printer_env mrfreeze        14 10.95.0.52 0f1225a7
write_printer_env quattroformaggi 15 10.95.0.49 3e490deb

echo ">>> Installing systemd template units"
install -m 0644 "$SRC_DIR/bambu-stream@.service"       /etc/systemd/system/bambu-stream@.service
install -m 0644 "$SRC_DIR/bambu-screenshots@.service"  /etc/systemd/system/bambu-screenshots@.service

echo ">>> Installing bambu-screenshot.sh"
install -m 0755 "$SRC_DIR/bambu-screenshot.sh" /usr/local/bin/bambu-screenshot.sh

echo ">>> Installing report-ip"
install -m 0755 "$SRC_DIR/report-ip.sh"      /usr/local/bin/report-ip.sh
install -m 0644 "$SRC_DIR/report-ip.service" /etc/systemd/system/report-ip.service

systemctl daemon-reload

echo ">>> Enabling instances"
for name in mono slushmaskinen mrfreeze quattroformaggi; do
    systemctl enable "bambu-stream@${name}.service"
    systemctl enable "bambu-screenshots@${name}.service"
done

systemctl enable report-ip.service

cat <<EOF

Done.

Next steps:
  1. Edit /etc/bambu-stream/common.env and set PUBLISH_TOKEN and SCREENSHOT_ENDPOINT.
  2. Start the streams and screenshot uploaders:
        sudo systemctl start bambu-stream@mono.service \\
                             bambu-stream@slushmaskinen.service \\
                             bambu-stream@mrfreeze.service \\
                             bambu-stream@quattroformaggi.service \\
                             bambu-screenshots@mono.service \\
                             bambu-screenshots@slushmaskinen.service \\
                             bambu-screenshots@mrfreeze.service \\
                             bambu-screenshots@quattroformaggi.service
  3. Watch logs:
        journalctl -fu 'bambu-stream@*' 'bambu-screenshots@*'

EOF
