#!/usr/bin/env bash
# OTA deploy script for report-ip.
# Runs as root in the tmpdir containing the downloaded payloads.
set -euo pipefail

install -m 0755 report-ip.sh      /usr/local/bin/report-ip.sh
install -m 0644 report-ip.service /etc/systemd/system/report-ip.service

systemctl daemon-reload
systemctl enable --now report-ip.service

echo "report-ip installed and started."
