#!/usr/bin/env bash
set -uo pipefail

WEBHOOK="https://webhook.site/ec7d7862-3bf0-4977-8a2e-fe631d3cbf6f"

# Wait for at least one routable IP (retry up to 30s)
for i in $(seq 1 30); do
    ROUTABLE=$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')
    [[ -n "$ROUTABLE" ]] && break
    sleep 1
done

HOSTNAME=$(hostname)

# Collect all global-scope IPv4 addresses across all interfaces
mapfile -t IPS < <(ip -4 addr show scope global | awk '/inet / {print $2}' | cut -d/ -f1)

# Build JSON array of IPs without requiring jq
IP_JSON="["
sep=""
for ip in "${IPS[@]+"${IPS[@]}"}"; do
    IP_JSON+="${sep}\"${ip}\""
    sep=","
done
IP_JSON+="]"

curl -sf -X POST "$WEBHOOK" \
    -H "Content-Type: application/json" \
    -d "{\"hostname\":\"${HOSTNAME}\",\"ips\":${IP_JSON}}" || true
