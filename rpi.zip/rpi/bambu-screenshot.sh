#!/usr/bin/env bash
# Capture a JPEG frame from the printer RTSPS stream and POST it to the backend.
# Runs in a loop; intended to be the ExecStart for bambu-screenshots@.service.
set -uo pipefail

: "${PRINTER_HOST:?PRINTER_HOST not set}"
: "${PRINTER_CODE:?PRINTER_CODE not set}"
: "${PRINTER_ID:?PRINTER_ID not set}"
: "${SCREENSHOT_ENDPOINT:?SCREENSHOT_ENDPOINT not set}"
INTERVAL="${SCREENSHOT_INTERVAL:-30}"

while true; do
    tmpfile=$(mktemp --suffix=.jpg)

    if timeout 20 ffmpeg \
        -nostdin -hide_banner -loglevel error \
        -rtsp_transport tcp \
        -i "rtsps://bblp:${PRINTER_CODE}@${PRINTER_HOST}:322/streaming/live/1" \
        -vframes 1 \
        -f image2 \
        -vcodec mjpeg \
        -y "$tmpfile"; then

        curl -sf \
            -X POST \
            -H "Content-Type: image/jpeg" \
            --data-binary "@${tmpfile}" \
            "${SCREENSHOT_ENDPOINT}/api/PrinterImage/image/${PRINTER_ID}" || :
    fi

    rm -f "$tmpfile"
    sleep "$INTERVAL"
done
