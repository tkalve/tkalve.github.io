#!/usr/bin/env bash
# Install the bambu-stream systemd service and report-ip utility.
# Place common.env and per-printer <name>.env files alongside this script
# before running; they will be copied to /etc/bambu-stream/.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run as root: sudo $0" >&2
    exit 1
fi

SRC_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

echo ">>> Installing dependencies"
apt-get update -y
apt-get install -y --no-install-recommends ffmpeg ca-certificates curl

echo ">>> Creating /etc/bambu-stream"
install -d -m 0755 /etc/bambu-stream
echo ">>> Copying env files from $SRC_DIR/env"
found_env=0
for f in "$SRC_DIR/env"/*.env; do
    [[ -e "$f" ]] || continue
    found_env=1
    target="/etc/bambu-stream/$(basename "$f")"
    if [[ -e "$target" ]]; then
        echo "    keep   $target (exists)"
    else
        install -m 0640 "$f" "$target"
        echo "    write  $target"
    fi
done
if [[ $found_env -eq 0 ]]; then
    echo "    WARNING: no .env files found in $SRC_DIR/env" >&2
    echo "    Copy common.env.example → common.env and add per-printer <name>.env files." >&2
fi

echo ">>> Installing systemd template unit"
install -m 0644 "$SRC_DIR/bambu-stream@.service" /etc/systemd/system/bambu-stream@.service

echo ">>> Installing bambu-stream.sh"
install -m 0755 "$SRC_DIR/bambu-stream.sh" /usr/local/bin/bambu-stream.sh

echo ">>> Installing report-ip"
install -m 0755 "$SRC_DIR/report-ip.sh"      /usr/local/bin/report-ip.sh
install -m 0644 "$SRC_DIR/report-ip.service" /etc/systemd/system/report-ip.service

systemctl daemon-reload
systemctl enable report-ip.service

echo ">>> Enabling stream instances"
streams=()
for f in /etc/bambu-stream/*.env; do
    name="$(basename "$f" .env)"
    [[ "$name" == "common" ]] && continue
    systemctl enable "bambu-stream@${name}.service"
    streams+=("$name")
done

cat <<EOF

Done.

EOF

if [[ ${#streams[@]} -gt 0 ]]; then
    echo "Start the streams:"
    for name in "${streams[@]}"; do
        echo "    sudo systemctl start bambu-stream@${name}.service"
    done
else
    echo "No per-printer env files found yet. Add them to /etc/bambu-stream/ and run:"
    echo "    sudo systemctl enable --now bambu-stream@<name>.service"
fi

echo ""
echo "Watch logs:  journalctl -fu 'bambu-stream@*'"
echo ""
