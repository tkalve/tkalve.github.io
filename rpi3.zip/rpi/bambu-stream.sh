#!/usr/bin/env bash
# Stream printer RTSPS to cloud relay as HLS-over-HTTPS.
# ffmpeg segments the stream locally and PUTs each segment + playlist to the
# relay via short-lived requests. This avoids ACA/Envoy request-body buffering
# that would break a single long-lived streaming POST.
# Runs in a loop so it self-heals on any failure.

set -uo pipefail

: "${PRINTER_HOST:?PRINTER_HOST not set}"
: "${PRINTER_CODE:?PRINTER_CODE not set}"
: "${RELAY_HOST:?RELAY_HOST not set}"
: "${STREAM_NAME:?STREAM_NAME not set}"
: "${PUBLISH_TOKEN:?PUBLISH_TOKEN not set}"

while true; do
    ffmpeg \
        -nostdin -hide_banner -loglevel warning \
        -rtsp_transport tcp \
        -use_wallclock_as_timestamps 1 \
        -i "rtsps://bblp:${PRINTER_CODE}@${PRINTER_HOST}:322/streaming/live/1" \
        -c copy \
        -f hls \
        -hls_time 2 \
        -hls_list_size 5 \
        -hls_flags delete_segments \
        -hls_segment_type mpegts \
        -hls_segment_filename "seg%d.ts" \
        -method PUT \
        -headers "Authorization: Bearer ${PUBLISH_TOKEN}\r\n" \
        "https://${RELAY_HOST}/ingest/${STREAM_NAME}/index.m3u8"

    echo "[bambu-stream] Stream ended, restarting in 2s…" >&2
    sleep 2
done
