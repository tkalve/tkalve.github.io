#!/usr/bin/env bash
# Builds an otamaker package inside a Linux Docker container.
# This ensures tar/zstd produces a frame compatible with rpi-ota-applicator.
#
# Usage: ./rpi/build-ota.sh [--version <ver>] [--out <file>]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VERSION="$(date +%Y%m%d%H%M%S)"
OUTFILE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --version) VERSION="$2"; shift 2 ;;
    --out)     OUTFILE="$2"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

OUTFILE="${OUTFILE:-bambu-stream-${VERSION}.tar.zst}"
YAML_FILE="${SCRIPT_DIR}/_build.ota.yaml"

# Generate YAML with paths relative to /work (the docker mount point)
cat > "${YAML_FILE}" <<YAML
artefact:
  name: bambu-stream
  version: "${VERSION}"
  description: Bambu printer MPEG-TS stream relay services
  device_type: rpi

payloads:
- name: common.env              # /work/env/common.env
  type: tmpfile
- name: mono.env                # /work/env/mono.env
  type: tmpfile
- name: mrfreeze.env            # /work/env/mrfreeze.env
  type: tmpfile
- name: quattroformaggi.env     # /work/env/quattroformaggi.env
  type: tmpfile
- name: slushmaskinen.env       # /work/env/slushmaskinen.env
  type: tmpfile
- name: bambu-stream.sh         # /work/rpi/bambu-stream.sh
  type: tmpfile
- name: bambu-stream@.service   # /work/rpi/bambu-stream@.service
  type: tmpfile
- name: installer               # /work/rpi/ota-install.sh
  type: script
YAML

docker run --rm \
  -v "${REPO_ROOT}:/work" \
  python:3-slim \
  bash -c "apt-get update -q && apt-get install -y -q tar zstd > /dev/null 2>&1 && \
    python3 /work/rpi/otamaker --writesum /work/rpi/_build.ota.yaml /work/rpi/${OUTFILE} && \
    zstd -d /work/rpi/${OUTFILE} -o /work/rpi/_tmp.tar && \
    zstd --content-size -f /work/rpi/_tmp.tar -o /work/rpi/${OUTFILE} && \
    rm /work/rpi/_tmp.tar && \
    sha256sum /work/rpi/${OUTFILE} | cut -d' ' -f1 > /work/rpi/${OUTFILE}.sha256sum && \
    echo 'SHA256 (recompressed):' && cat /work/rpi/${OUTFILE}.sha256sum"

rm -f "${YAML_FILE}"

echo ""
echo "Package: ${SCRIPT_DIR}/${OUTFILE}"
[[ -f "${SCRIPT_DIR}/${OUTFILE}.sha256sum" ]] && echo "SHA256:  $(cat "${SCRIPT_DIR}/${OUTFILE}.sha256sum")"
