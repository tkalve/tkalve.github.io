#!/usr/bin/env bash
# Wrapper called by bambu-stream@.service
# All variables are injected by systemd from EnvironmentFile directives.
set -euo pipefail

exec ffmpeg \
  -nostdin \
  -hide_banner \
  -loglevel warning \
  -rtsp_transport tcp \
  -use_wallclock_as_timestamps 1 \
  -i "rtsps://bblp:${PRINTER_CODE}@${PRINTER_HOST}:322/streaming/live/1" \
  -c copy \
  -f mpegts \
  -headers "X-Api-Key: ${PUBLISH_TOKEN}\r\n" \
  "wss://${RELAY_HOST}/ingest/${STREAM_NAME}"
