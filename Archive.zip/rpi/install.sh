#!/usr/bin/env bash
# Installs bambu-stream systemd services on a Raspberry Pi.
# Run as root: sudo ./install.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_DIR="$(cd "${SCRIPT_DIR}/../env" && pwd)"
ENV_DEST="/etc/bambu-stream"
SERVICE_TEMPLATE="bambu-stream@.service"
WRAPPER="/usr/local/bin/bambu-stream.sh"

# ── sanity checks ──────────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  echo "Error: run as root (sudo $0)" >&2
  exit 1
fi

if ! command -v ffmpeg &>/dev/null; then
  echo "Error: ffmpeg not found. Install it first:" >&2
  echo "  sudo apt-get install -y ffmpeg" >&2
  exit 1
fi

# ── install env files ──────────────────────────────────────────────────────────
echo "Installing env files to ${ENV_DEST}/ ..."
install -d -m 750 "${ENV_DEST}"
install -m 640 "${ENV_DIR}/common.env" "${ENV_DEST}/common.env"

# Collect printer names from per-printer env files (everything except common.env)
PRINTERS=()
for f in "${ENV_DIR}"/*.env; do
  name="$(basename "${f}" .env)"
  if [[ "${name}" == "common" ]]; then continue; fi
  install -m 640 "${f}" "${ENV_DEST}/${name}.env"
  PRINTERS+=("${name}")
  echo "  installed ${name}.env"
done

if [[ ${#PRINTERS[@]} -eq 0 ]]; then
  echo "Error: no printer env files found in ${ENV_DIR}/" >&2
  exit 1
fi

# ── install wrapper script ─────────────────────────────────────────────────────
echo "Installing wrapper script to ${WRAPPER} ..."
install -m 755 "${SCRIPT_DIR}/bambu-stream.sh" "${WRAPPER}"

# ── install systemd service template ──────────────────────────────────────────
echo "Installing systemd service template ..."
install -m 644 "${SCRIPT_DIR}/${SERVICE_TEMPLATE}" "/etc/systemd/system/${SERVICE_TEMPLATE}"

systemctl daemon-reload

# ── enable and start one service per printer ──────────────────────────────────
echo ""
echo "Enabling and starting services ..."
for name in "${PRINTERS[@]}"; do
  unit="bambu-stream@${name}.service"
  systemctl enable "${unit}"
  systemctl restart "${unit}"
  echo "  ✓ ${unit}"
done

echo ""
echo "Done. Check status with:"
for name in "${PRINTERS[@]}"; do
  echo "  systemctl status bambu-stream@${name}.service"
done
