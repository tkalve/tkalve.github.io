#!/usr/bin/env bash
# OTA install script — runs as root inside the otamaker temp directory.
# All payload tmpfiles are available in the current working directory.
set -euo pipefail

ENV_DEST="/etc/bambu-stream"
WRAPPER="/usr/local/bin/bambu-stream.sh"
SERVICE_TEMPLATE="bambu-stream@.service"

# ── ffmpeg check ───────────────────────────────────────────────────────────────
if ! command -v ffmpeg &>/dev/null; then
  echo "Error: ffmpeg not installed. Run: sudo apt-get install -y ffmpeg" >&2
  exit 1
fi

# ── install env files ──────────────────────────────────────────────────────────
install -d -m 750 "${ENV_DEST}"
install -m 640 common.env "${ENV_DEST}/common.env"

PRINTERS=()
for f in *.env; do
  name="${f%.env}"
  if [[ "${name}" == "common" ]]; then continue; fi
  install -m 640 "${f}" "${ENV_DEST}/${name}.env"
  PRINTERS+=("${name}")
  echo "  installed ${name}.env"
done

if [[ ${#PRINTERS[@]} -eq 0 ]]; then
  echo "Error: no printer env files found in package" >&2
  exit 1
fi

# ── install wrapper script ─────────────────────────────────────────────────────
install -m 755 bambu-stream.sh "${WRAPPER}"

# ── install systemd service template ──────────────────────────────────────────
install -m 644 "${SERVICE_TEMPLATE}" "/etc/systemd/system/${SERVICE_TEMPLATE}"
systemctl daemon-reload

# ── enable and start one service per printer ──────────────────────────────────
for name in "${PRINTERS[@]}"; do
  unit="bambu-stream@${name}.service"
  systemctl enable "${unit}"
  systemctl restart "${unit}"
  echo "  ✓ ${unit}"
done

echo "Done."
# Return code 2 = success, request reboot (ensures systemd picks up all changes cleanly)
exit 2
