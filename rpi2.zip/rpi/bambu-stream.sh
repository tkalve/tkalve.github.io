#!/usr/bin/env bash
# Stream printer RTSPS to cloud relay as one continuous MPEG-TS POST.
# The relay segments it into HLS on its side, so a single connection
# carries the whole stream — no per-segment PUT round-trips.
# Runs in a loop so it self-heals on any failure.

set -uo pipefail

: "${PRINTER_HOST:?PRINTER_HOST not set}"
: "${PRINTER_CODE:?PRINTER_CODE not set}"
: "${RELAY_HOST:?RELAY_HOST not set}"
: "${STREAM_NAME:?STREAM_NAME not set}"
: "${PUBLISH_TOKEN:?PUBLISH_TOKEN not set}"

while true; do
    ffmpeg \
        -nostdin -hide_banner -loglevel warning \
        -rtsp_transport tcp \
        -use_wallclock_as_timestamps 1 \
        -i "rtsps://bblp:${PRINTER_CODE}@${PRINTER_HOST}:322/streaming/live/1" \
        -c copy \
        -f mpegts \
        pipe:1 \
    | curl --http1.1 -sf \
        -X POST \
        -H "Authorization: Bearer ${PUBLISH_TOKEN}" \
        -H "Content-Type: video/mp2t" \
        --data-binary @- \
        "https://${RELAY_HOST}/ingest/${STREAM_NAME}/live" \
    || true

    echo "[bambu-stream] Stream ended, restarting in 2s…" >&2
    sleep 2
done
